<?php
	mysql_connect("localhost","root","") or die("sai");
    mysql_select_db("gtmart") or die("sai database");
    mysql_query("SET NAMES 'utf8'");
?>