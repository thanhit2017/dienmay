<?php 

?>
<div class="footer_head">
	<ul>
		<li><a href="index.php">Trang chủ</a></li>
		<li><a href="1.html">Giới thiệu</a></li>
		<li><a href="5.html">Đối tác</a></li>
		<li><a href="7.html">Liên hệ</a></li>
	</ul>
	<div class="footHead_right">
		<p>
			<span>Lượt truy cập</span>
			<strong>573524</strong>
		<div style="clear: both;"></div>
		</p>

		
	</div>
	<div style="clear: both;"></div>
</div>
<div class="footer_content">
	<h3>Siêu thị mua bán hàng online hàng đầu tại Hà Nội - gtmart.vn</h3>
	<p>Bản quyền © 2011 Công ty TNHH Thương Mại và Dịch Vụ Gia Thịnh</p>
	<p>VPGD: Số 44, ngõ 30 Tạ Quang Bửu, Bách Khoa, Hai Bà Trưng, Hà Nội</p>
	<p>Điện thoại: 04.3623 0588    Fax: 04 3623 1376. Hotline: 0904.99.55.86 (Mrs Hà)</p>
</div>