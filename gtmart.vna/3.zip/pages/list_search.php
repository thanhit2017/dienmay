<?php 
		$page=$_GET['page'];
		$mang = explode('-', $page);
		
	$lsp=$mang[1];
	$made=$mang[2];
	$brand=$mang[3];
	$price=$mang[4];
	$list_product_menu=list_search($lsp,$made,$brand,$price);
?>
<div class="main-listSp">

	<div class="item-list">
		<h1 id="h1">
			Search
			<a href="pageDetailpro.php">Xem thêm</a>
		</h1>
		<div class="listSp-items">
		<?php 
			while($row=mysql_fetch_array($list_product_menu)){
		?>
			<div class="col4">
				<div class="itemSp">
					<div class="Sp_title">
						<a href="10-<?php echo $row[0]?>-<?php echo $row[2];?>.html">
							<?php echo $row[1]?>
						</a>
					</div>
					<a href="10-<?php echo $row[0]?>-<?php echo $row[2];?>.html" class="img">
						<img src="images/	<?php echo $row[4]?>">
					</a>
					<p>	<?php echo $row[3]?></p>
					<p>
						Đặt hàng: 
						<a href="#"><i class="fa fa-shopping-cart cart1"></i></a>
					</p>
				</div>
			</div>
		<?php 
			}
		?>		
			
			<div class="pagina" style="text-align: center;">
			
		</div>

			<div style="clear: both;"></div>
		</div>
	</div>
   

</div>
<!--:: END SẢN PHẨM ::-->