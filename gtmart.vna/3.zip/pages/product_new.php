<div class="main-listSp">

	<div class="item-list">
		<h1 id="h1">Sản phẩm mới
		
		</h1>
		<div class="listSp-items">
			<?php 
			$list =list_product_news('');
			include ("list_product.php");
			?>		
			<div style="clear: both;"></div>
		</div>
	  
	</div>


</div>