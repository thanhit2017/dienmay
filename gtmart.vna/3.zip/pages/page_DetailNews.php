<!--:: Nội Dung chi tiết::-->
<div class="mainGaneral">
	<h1 id="h1">Nội Dung chi tiết</h1>
	<?php 
		$page=$_GET['page'];
		$mang = explode('-', $page);
		$id_news = $mang[1];
		$news_detail=detail_table('news',$id_news);
	?>
	<p>
		<span><?php echo $news_detail[6]?></span>
	<div style="clear: both;"></div>
	</p> 
	
	<h2 id="h2"><?php echo $news_detail[1]?></h2>
	<div class="introContent">
		<?php echo $news_detail[5]?>
	</div>
</div>
<!--:: Nội Dung chi tiết ::-->
