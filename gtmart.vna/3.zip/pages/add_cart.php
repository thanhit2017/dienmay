<?php

    if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
	
	$id=$_GET['id_product'];
	
	if(isset($_SESSION['cart'][$id]))
{
	$qty = $_SESSION['cart'][$id] + 1;
}
else
{
	$qty=1;
}
$_SESSION['cart'][$id]=$qty;
echo '<script>window.location.href = "index.php?page=13";</script>';
exit();
?>
