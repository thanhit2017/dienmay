                                    <div class="main-listSp">
                                        <div class="item-list">
                                            <h1 id="h1">Sản phẩm nổi bật
											<a href="index.php?page=14" style="color:white">Xem Thêm</a>
											</h1>
											
												<?php 
													include ("page_index_1.php");
												?>
											
                                        </div>
                                        <div class="item-list">
                                            <h1 id="h1">Sản phẩm mới
											<a href="index.php?page=15" style="color:white">Xem Thêm</a>
											</h1>
                                            <?php 
												include ("page_index_2.php");
											?>	
                                          
                                        </div>


                                    </div>