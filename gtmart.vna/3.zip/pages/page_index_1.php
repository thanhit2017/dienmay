<div class="listSp-items">
	<?php 
		$list = list_product_highlight('limit 6');
		include ("list_product.php");
	?>
	
	<div style="clear: both;"></div>
</div>