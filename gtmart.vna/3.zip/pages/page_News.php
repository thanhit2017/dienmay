<!--:: LIST TIN TỨC ::-->
<?php 
	//****** Phân Trang ******///
$sotin1trang=5;
if(isset($_GET["trang"])){
	$trang=$_GET["trang"];
	settype($trang,"int");
}
else{
	$trang=1;
	}
$from=($trang-1)*$sotin1trang;
//****** ket thuc phan trang ******//
?>	
<div class="newsList">
	<h1 id="h1">Tin tức</h1>
	<?php 
		$list_news=list_news($from,$sotin1trang);
		while($row=mysql_fetch_array($list_news)){
	?>
	<div class="newslistItem">
		<div class="col3">
			<a href="11-<?php echo $row[0]?>.html">
				<img src="images/<?php echo $row[3]?>">
			</a>
		</div>
		<div class="col9">
			<div class="itemlistContent">
				<a href="11-<?php echo $row[0]?>.html"><?php echo $row[1]?></a>
				<p id="time"><span><?php echo $row[6]?></span></p>
				<p id="nd">
					<?php echo $row[4]?>
				</p>
			</div>
		</div>
		<div style="clear: both;"></div>
		<p id="xt">
			<a href="11-<?php echo $row[0]?>.html">Xem tiếp <i class="fa fa-caret-right"></i></a>
		</p>
	</div>
		<?php }?>
		
		
	<div class="pagina" style="text-align: center;">
		<ul class="pagination" style="padding: 0;">
		 <?php 
		if($trang>tongsotrang && $trang>1 ){	
			echo   '<li><a href="index.php?page=3&trang='.($trang-1);

			echo '"><i class="fa fa-angle-double-left"></i></a></li>';
		}
		?>	
		<?php

				 $t=number_news();
				$tongsotin=mysql_num_rows($t);
				$tongsotrang=ceil($tongsotin/$sotin1trang);
				 for($i=1;$i<=$tongsotrang;$i++){
		?>		  

		 <li <?php
			if($trang == $i){
				echo "class='active'";
			}
		 ?> ><a href="index.php?page=3&trang=<?php echo $i?>"><?php echo $i?></a></li><?php }?>


		<?php 
				if ($trang < $tongsotrang){
						echo '<li><a href="index.php?page=3&trang='.($trang+1);
					
				echo'"><i class="fa fa-angle-double-right"></i></a></li>';
			}else{
			 $trang=1;	
			}
		?> 
		</ul>
	</div>

</div>
<!--:: END LIST TIN TỨC ::-->