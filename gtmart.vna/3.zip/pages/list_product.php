<?php 
	while($row=mysql_fetch_array($list)){
?>
<div class="col4">
	<div class="itemSp">
		<div class="Sp_title">
			<a href="10-<?php echo $row[0]?>-<?php echo $row[2];?>.html">
				<?php echo $row[1]?>
			</a>
		</div>
		<a href="10-<?php echo $row[0]?>-<?php echo $row[2];?>.html" class="img">
			<img src="images/<?php echo $row[4]?>">
		</a>
		  <p>Giá: <?php echo number_format($row[3],0,',','.').' VND';?></p>
		<p>
			Đặt hàng: 
			<a href="index.php?page=12&id_product=<?php echo $row[0]?>"><i class="fa fa-shopping-cart"></i></a>
		</p>
	</div>
</div>
<?php 
	}
?>
<div style="clear: both;"></div>